

<div class="container">
    <div class="d-flex align-items-center justify-content-between">
        <h1>Create new Product</h1>
        <a href="/admin/ranks" class="btn btn-primary">Go back to list</a>
    </div>

    

    <?php require_once "form.php"; ?>
</div>

