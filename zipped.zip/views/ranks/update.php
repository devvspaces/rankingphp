

<div class="container">
    <div class="d-flex align-items-center justify-content-between">
        <h1>Update Rank - <strong><?php echo $rank['name']; ?></strong></h1>
        <a href="/admin/ranks" class="btn btn-primary">Go back to list</a>
    </div>

    

    <?php require_once "form.php"; ?>
</div>