# rankingphp
this is a project done for a client where i used fixed password system, ajax max update with jquery
